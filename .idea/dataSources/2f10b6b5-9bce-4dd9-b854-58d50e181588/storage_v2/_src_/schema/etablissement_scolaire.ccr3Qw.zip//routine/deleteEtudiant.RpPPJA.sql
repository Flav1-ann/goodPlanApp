create
    definer = root@localhost procedure deleteEtudiant(IN e_id_etudiant int, OUT erreur int)
BEGIN
    DECLARE is_row_deleted INT;

    START TRANSACTION;
    
    IF e_id_etudiant > 0 THEN
    
        -- delete personne

        DELETE FROM `personne`
        WHERE personne.id_personne = e_id_etudiant;

        SET is_row_deleted = ROW_COUNT();
       
        IF is_row_deleted = 1 THEN

            -- delete personne_phys
            DELETE FROM `personne_phys`
            WHERE personne_phys.id_phys = e_id_etudiant;
            
            -- delete étudiant 
            
            DELETE FROM `etudiant`
            WHERE etudiant.id_etudiant = e_id_etudiant;
            
            -- Commit queries
            SET erreur = 0;
            COMMIT;
        ELSE
            SET erreur = -1;
            ROLLBACK;
        END IF;
    ELSE
        -- Commit if id isn't correct ROLLBACK to cancel any actions did before
        ROLLBACK;
    END IF;
END;

