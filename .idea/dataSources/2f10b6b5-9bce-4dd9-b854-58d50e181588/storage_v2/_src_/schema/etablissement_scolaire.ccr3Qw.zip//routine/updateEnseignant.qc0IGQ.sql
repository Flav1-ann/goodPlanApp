create
    definer = root@localhost procedure updateEnseignant(IN en_id_enseignant int, IN en_nom varchar(50),
                                                        IN en_prenom varchar(50), IN en_email varchar(50),
                                                        IN en_adresse varchar(50), IN en_telephone varchar(50),
                                                        IN en_mdp varchar(50), IN en_salt varchar(50),
                                                        IN en_nom_role varchar(50), IN en_mat_ens varchar(50),
                                                        OUT erreur int)
BEGIN
    DECLARE is_row_updated INT;
    
    START TRANSACTION;
    
    IF en_id_enseignant > 0 THEN
    
        -- Update personne
        UPDATE `personne`
        SET `nom`=en_nom,`email`=en_email,`adresse`=en_adresse,`telephone`=en_telephone 
        WHERE personne.id_personne = en_id_enseignant;
        
        SET is_row_updated = ROW_COUNT();

        IF is_row_updated = 1 THEN
            
            -- Update personnen_phys
            UPDATE `personne_phys` 
            SET `prenom`=en_prenom,`mdp`=en_mdp,`salt`=en_salt,`id_role`=(SELECT id_role from role where role.libelle = en_nom_role) 
            WHERE personne_phys.id_phys = en_id_enseignant;

            UPDATE `enseignant`
            SET `mat_ens`=en_mat_ens
            WHERE enseignant.mat_ens = en_id_enseignant;

            SET erreur = 0;

            -- Commit queries
            COMMIT;
        ELSE
            SET erreur = -1;
            ROLLBACK;
            -- Update étudiant
        END IF;
    ELSE
        -- Commit if id isn't correct ROLLBACK to cancel any actions did before
        ROLLBACK;
    END IF;
END;

