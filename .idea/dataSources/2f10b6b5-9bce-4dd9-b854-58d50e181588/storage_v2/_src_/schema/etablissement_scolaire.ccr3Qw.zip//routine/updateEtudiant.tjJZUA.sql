create
    definer = root@localhost procedure updateEtudiant(IN e_id_etudiant int, IN e_nom varchar(50),
                                                      IN e_prenom varchar(50), IN e_email varchar(50),
                                                      IN e_adresse varchar(50), IN e_telephone varchar(50),
                                                      IN e_mdp varchar(50), IN e_salt varchar(50),
                                                      IN e_nom_role varchar(50), IN e_date_naissance date,
                                                      OUT erreur int)
BEGIN
    DECLARE is_row_updated INT;

    START TRANSACTION;
    
    IF e_id_etudiant > 0 THEN
    
        -- Update personne
        UPDATE `personne`
        SET `nom`=e_nom,`email`=e_email,`adresse`=e_adresse,`telephone`=e_telephone 
        WHERE personne.id_personne = e_id_etudiant;
        
        SET is_row_updated = ROW_COUNT();

        IF is_row_updated = 1 THEN
            -- Update personne_phys
            
            UPDATE `personne_phys` 
            SET `prenom`=e_prenom,`mdp`=e_mdp,`salt`=e_salt,`id_role`=(SELECT id_role from role where role.libelle = e_nom_role) 
            WHERE personne_phys.id_phys = e_id_etudiant;
            
            -- Update étudiant
            
            UPDATE `etudiant`
            set etudiant.date_naissance=e_date_naissance
            WHERE etudiant.id_etudiant = e_id_etudiant;

            SET erreur = 0;

            -- Commit queries
            COMMIT;
        ELSE  
            SET erreur = -1;
            ROLLBACK;
        END IF;
    ELSE
        -- ROLLBACK to cancel any actions did before due to error
        ROLLBACK;
    END IF;
END;

