create
    definer = root@localhost procedure updateEcole(IN ec_id_ecole int, IN ec_nom varchar(50), IN ec_email varchar(50),
                                                   IN ec_adresse varchar(50), IN ec_telephone varchar(50),
                                                   IN ec_id_directeur varchar(50), OUT erreur int)
BEGIN
    DECLARE is_row_updated INT;

    START TRANSACTION;
    
    IF ec_id_ecole > 0 THEN
    
        -- Update personne
        UPDATE `personne`
        SET `nom`=e_nom,`email`=e_email,`adresse`=e_adresse,`telephone`=e_telephone 
        WHERE personne.id_personne = ec_id_ecole;
        
        SET is_row_updated = ROW_COUNT();

        IF is_row_updated = 1 THEN
            -- Update personne_phys
            
            UPDATE `ecole`
            SET `id_directeur`= ec_id_directeur
            WHERE ecole.id_ecole = ec_id_ecole;

            SET erreur = 0;

            -- Commit queries
            COMMIT;
        ELSE 
            SET erreur = -1;
            ROLLBACK;
        END IF;
    ELSE
        -- ROLLBACK to cancel any actions did before due to error
        ROLLBACK;
    END IF;
END;

