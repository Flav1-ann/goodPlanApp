create
    definer = root@localhost procedure insertEcole(IN ec_nom varchar(50), IN ec_email varchar(50),
                                                   IN ec_adresse varchar(50), IN ec_telephone varchar(50),
                                                   IN ec_id_directeur varchar(50), OUT erreur int)
BEGIN
    DECLARE personne_id INT DEFAULT 0;
    DECLARE is_row_exist INT;

    SELECT EXISTS(SELECT * from personne WHERE personne.email = ec_email) as is_exist into is_row_exist;

    START TRANSACTION;
    INSERT INTO `personne`(`nom`, `email`, `adresse`, `telephone`) 
    VALUES (ec_nom, ec_email, ec_adresse, ec_telephone);
    SET personne_id = LAST_INSERT_ID();
    IF (personne_id > 0) && (is_row_exist != 1) THEN
        INSERT INTO `ecole`(`id_ecole`, `id_directeur`) VALUES (personne_id, ec_id_directeur );
        SET erreur = 0;
        COMMIT;
    ELSEIF personne_id = 0 THEN
        SET erreur = -1;
        ROLLBACK;
    ELSEIF is_row_exist = 1 THEN
        SET erreur = -2;
        ROLLBACK;
    END IF;
END;

