create
    definer = root@localhost procedure updateResponsable(IN res_id_responsable int, IN res_nom varchar(50),
                                                         IN res_prenom varchar(50), IN res_email varchar(50),
                                                         IN res_adresse varchar(50), IN res_telephone varchar(50),
                                                         IN res_mdp varchar(50), IN res_salt varchar(50),
                                                         IN res_nom_role varchar(50), OUT erreur int)
BEGIN
    DECLARE is_row_updated INT;
    START TRANSACTION;
    
    IF res_id_responsable > 0 THEN
    
        -- Update personne
        UPDATE `personne`
        SET `nom`=res_nom,`email`=res_email,`adresse`=res_adresse,`telephone`=res_telephone 
        WHERE personne.id_personne = res_id_responsable;
        
        SET is_row_updated = ROW_COUNT();
        
        IF is_row_updated = 1 THEN
            -- Update personnres_phys
            UPDATE `personne_phys`
            SET `prenom`=res_prenom,`mdp`=res_mdp,`salt`=res_salt, `id_role`= (SELECT id_role from role where role.libelle = res_nom_role)
            WHERE personne_phys.id_phys = res_id_responsable;
            
            SET erreur = 0;

            -- Commit queries
            COMMIT;
        ELSE
            SET erreur = -1;
            ROLLBACK;
        END IF;
    ELSE
        -- Commit if id isn't correct ROLLBACK to cancel any actions did before
        ROLLBACK;
    END IF;
END;

