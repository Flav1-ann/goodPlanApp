create
    definer = root@localhost procedure insertEnseignant(IN en_nom varchar(50), IN en_prenom varchar(50),
                                                        IN en_email varchar(50), IN en_adresse varchar(50),
                                                        IN en_telephone varchar(50), IN en_mdp varchar(50),
                                                        IN en_salt varchar(50), IN en_nom_role varchar(50),
                                                        IN en_mat_ens varchar(50), OUT erreur int)
BEGIN
    DECLARE personne_id INT DEFAULT 0;
    DECLARE is_row_exist INT;

    SELECT EXISTS(SELECT * from personne WHERE personne.email = en_email) as is_exist into is_row_exist;

    START TRANSACTION;
    INSERT INTO `personne`(`nom`, `email`, `adresse`, `telephone`) 
    VALUES (en_nom, en_email, en_adresse, en_telephone);
    SET personne_id = LAST_INSERT_ID();
    IF (personne_id > 0) && (is_row_exist != 1) THEN
        INSERT INTO `personne_phys`(`id_phys`, `prenom`, `mdp`, `salt`, `id_role`) 
        VALUES (personne_id, en_prenom, en_mdp, en_salt, (SELECT id_role from role where role.libelle = en_nom_role) );
        INSERT INTO `enseignant`(`id_ens`, `mat_ens`) 
        VALUES (personne_id, en_mat_ens);
        SET erreur = 0;
        COMMIT;
    ELSEIF personne_id = 0 THEN
        SET erreur = -1;
        ROLLBACK;
    ELSEIF is_row_exist = 1 THEN
        SET erreur = -2;
        ROLLBACK;
    END IF;
END;

